import React from "react";

const AdaPrice = () => {
  return <>AdaPrice</>;
};

export default AdaPrice;
