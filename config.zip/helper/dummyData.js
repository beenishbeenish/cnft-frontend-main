const dummyData = [
  {
    title: "CREATOR",
    img: "/images/royalty/card1.png",
    arrow: true,
  },
  {
    title: "YOU GET PAID",
    img: "/images/royalty/card2.png",
    arrow: true,
  },
  {
    title: "BUYER SELLS",
    img: "/images/royalty/card3.png",
    arrow: true,
  },
  {
    title: "YOU GET PAID",
    img: "/images/royalty/card4.png",
    arrow: false,
  },
  {
    title: "NEW BUYER SELLS",
    img: "/images/royalty/card5.png",
    arrow: true,
  },
  {
    title: "YOU GET PAID",
    img: "/images/royalty/card6.png",
    arrow: true,
  },
  {
    title: "NEW BUYER SELLS",
    img: "/images/royalty/card7.png",
    arrow: true,
  },
  {
    title: "YOU GET PAID",
    img: "/images/royalty/card8.png",
    arrow: false,
  },
];

export { dummyData };
