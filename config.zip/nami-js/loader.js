// import * as wasm from "@emurgo/cardano-serialization-lib-browser/cardano_serialization_lib";
// class Loader {
//   async load() {
//     if (this._wasm) return;
//     /**
//      * @private
//      */
//     this._wasm = wasm;
//   }

//   get Cardano() {
//     return this._wasm;
//   }
// }

// export default new Loader();
