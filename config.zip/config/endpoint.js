// export const baseURL = "http://192.168.100.64:4001/api";
// export const baseURL = "http://208.64.33.106:4001/api";
// export const baseURL = "http://192.168.1.47:4001/api";
//
// export const baseURL = "http://192.168.100.26:3002/api/v1";
export const baseURL = "https://backend-cnft.thecbt.cyou/api";
// export const baseURL = "http://localhost:4001/api";
