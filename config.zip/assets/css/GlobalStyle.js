import { createGlobalStyle } from "styled-components";
const GlobalStyle = createGlobalStyle`
/* @import url("https://fonts.googleapis.com/css2?family=DM+Sans:wght@200;300;400;500;600;700;800&display=swap"); */

@font-face {
  font-family: oswald;
  src: url("/font/Oswald-VariableFont_wght.ttf");
}
@font-face {
  font-family: montserrat;
  src: url("/font/Montserrat-VariableFont_wght.ttf");
}
@font-face {
  font-family: proxima;
  src: url("/font/ProximaNova-Regular.ttf");
}
@font-face {
  font-family: poppin;
  src: url("/font/Poppins-Bold.ttf");
}
:root {
    --main-color: #121f57;
    --secondary-color: #46e7bc;
    --orange-color: #d89430;
    --light-grey-color: #B5B5B5;
    --grey-color: #707787;
    --error-color: #d32f2f;
    --light-white-color: #fff3;
    --box-color: #FFFFFF33;
    --dark-box-color: #3b3b3b4d;
  }
  * {
    margin: 0 ;
    padding: 0;
    box-sizing: border-box;
    /* text-transform: capitalize; */
  }
  body  {
    overflow-x: hidden;
    font-family: proxima;
  }
  .poppin {
    font-family : poppin !important;
  }
  .proxima {
    font-family : proxima !important;
  }
  .oswald {
    font-family : oswald !important;
  }
  .montserrat {
    font-family : montserrat !important;
  }
  
  .font_12 {
    font-size: 12px !important ;
  }

  .error {
    color : var(--error-color)
  }
  .space_between {
    display: flex ;
    align-items: center ;
    justify-content:space-between ;
  }
  .light_white_bg {
    background: var(--light-white-color);
  }
.uppercase {
  text-transform: uppercase;
}
.initialcase{
  text-transform: initial !important;
}
.light_text {
  opacity: 0.7;
  color:#fff;
}
  .main_background {
    position: absolute;
    z-index: -2;
    width: 100%;
    height: 100%;
    top: 0px;
    left: 0px;
    background: linear-gradient(
      rgb(37, 54, 160) 0%,
      rgb(22, 56, 114) 10%,
      rgb(87, 181, 154) 45%,
      rgb(22, 56, 114) 90%,
      rgb(37, 54, 160) 100%
    );
  }
  
  li {
    list-style: none;
  }
  body {
  font-family: montserrat;
  font-weight: 300;
  font-size: 16px;
  /* color: $general; */
  word-spacing: 0px;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  overflow-x: hidden;
}
    .text_center {
        text-align : center;
    }
    .bold {
        font-weight: bold !important;
    }
  .flex {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .flex_align {
    display: flex;
    align-items: center;
  }
  .table_icon {

  }

  .flex_align_center {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .br_15 {
    border-radius: 15px ;
  }
  .br_50 {
    border-radius: 50px !important ;
  }
  .text_white {
    color: #fff !important;
  }
  .btn {
    text-transform: initial !important;
    background: transparent !important;
    color: #fff !important ;
    border: 1px solid #fff !important;
    font-family : proxima !important;
    border-radius: 40px !important;
    /* width: 125px;  */
    padding: 10px 30px !important;
    transition: 0.4s;
    &:hover {
        background: var(--secondary-color) !important;
        /* border: 1px solid var(---secondary-color) !important; */
    }
  }
  .btn2 {
    text-transform: initial !important;
    background: var(--secondary-color) !important;
    color: #082655 !important ;
    font-family : proxima !important;
    border-radius: 40px !important;
    font-weight: bold  !important;
    padding: 10px 30px !important;
    transition: 0.4s;
    &:hover {
      opacity: 0.8;
        /* border: 1px solid var(---secondary-color) !important; */
    }
  }
  .w_100 {
    width: 100%;
  }
 
`;

export default GlobalStyle;
