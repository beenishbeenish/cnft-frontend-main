import React from "react";
import { useNavigate, Navigate } from "react-router";

export const navigationHandler = (url) => {
  
};
