import React from 'react'
// import gont "../../font/font2"
const ddf = () => {
  return (
    <div>ddf</div>
  )
}

export default ddf